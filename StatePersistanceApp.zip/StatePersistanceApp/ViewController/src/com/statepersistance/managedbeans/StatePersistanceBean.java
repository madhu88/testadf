package com.statepersistance.managedbeans;

import javax.faces.context.FacesContext;

import javax.servlet.http.HttpServletRequest;

public class StatePersistanceBean {
    public StatePersistanceBean() {
    }
    
    private String url;

    public String start() {
        System.out.println("start of default activity");
        HttpServletRequest request = (HttpServletRequest)
            FacesContext.getCurrentInstance().getExternalContext().getRequest();
        url = request.getRequestURI();
        System.out.println("url = " + url);
        System.out.println("end of default activity");
        return "gotoView1";
    }
    
    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
